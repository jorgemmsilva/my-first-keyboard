G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.8+1*
G04 #@! TF.CreationDate,2026-05-17T21:37:05+00:00*
G04 #@! TF.ProjectId,controller_overlay,636f6e74-726f-46c6-9c65-725f6f766572,0.1*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.8+1) date 2026-05-17 21:37:05*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.300000*%
G04 APERTURE END LIST*
D10*
X207762000Y-94142667D03*
X222194000Y-102661667D03*
M02*
