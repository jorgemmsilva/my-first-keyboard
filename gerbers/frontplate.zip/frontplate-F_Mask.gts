G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.8+1*
G04 #@! TF.CreationDate,2026-05-17T21:37:03+00:00*
G04 #@! TF.ProjectId,frontplate,66726f6e-7470-46c6-9174-652e6b696361,0.1*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.8+1) date 2026-05-17 21:37:03*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.300000*%
G04 APERTURE END LIST*
D10*
X109500000Y-71500000D03*
X109500000Y-90500000D03*
X185468000Y-61652667D03*
X143157000Y-103615000D03*
X214377304Y-112640080D03*
M02*
